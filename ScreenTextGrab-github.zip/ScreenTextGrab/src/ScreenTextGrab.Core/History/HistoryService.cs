using System.IO;
using Microsoft.Data.Sqlite;

namespace ScreenTextGrab.Core.History;

public record HistoryEntry
{
    public long Id { get; init; }
    public required string Text { get; init; }
    public string? SourceApplication { get; init; }
    public DateTime CapturedAt { get; init; } = DateTime.UtcNow;
    public string? Language { get; init; }
    public int WordCount => Text.Split(' ', StringSplitOptions.RemoveEmptyEntries).Length;
}

public interface IHistoryService : IDisposable
{
    Task AddAsync(HistoryEntry entry);
    Task<IReadOnlyList<HistoryEntry>> GetRecentAsync(int count = 50);
    Task<IReadOnlyList<HistoryEntry>> SearchAsync(string query);
    Task DeleteAsync(long id);
    Task ClearAllAsync();
    Task<int> GetCountAsync();
}

public class HistoryService : IHistoryService
{
    private readonly string _connectionString;

    public HistoryService(string? dbPath = null)
    {
        dbPath ??= Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "ScreenTextGrab", "history.db");

        Directory.CreateDirectory(Path.GetDirectoryName(dbPath)!);
        _connectionString = $"Data Source={dbPath}";

        InitializeDatabase();
    }

    private void InitializeDatabase()
    {
        using var connection = new SqliteConnection(_connectionString);
        connection.Open();

        var cmd = connection.CreateCommand();
        cmd.CommandText = """
            CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                source_application TEXT,
                captured_at TEXT NOT NULL DEFAULT (datetime('now')),
                language TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_history_captured_at ON history(captured_at DESC);
            CREATE VIRTUAL TABLE IF NOT EXISTS history_fts USING fts5(text, content=history, content_rowid=id);
            
            -- Triggers to keep FTS index in sync
            CREATE TRIGGER IF NOT EXISTS history_ai AFTER INSERT ON history BEGIN
                INSERT INTO history_fts(rowid, text) VALUES (new.id, new.text);
            END;
            CREATE TRIGGER IF NOT EXISTS history_ad AFTER DELETE ON history BEGIN
                INSERT INTO history_fts(history_fts, rowid, text) VALUES('delete', old.id, old.text);
            END;
        """;
        cmd.ExecuteNonQuery();
    }

    public async Task AddAsync(HistoryEntry entry)
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();

        var cmd = connection.CreateCommand();
        cmd.CommandText = """
            INSERT INTO history (text, source_application, captured_at, language)
            VALUES (@text, @source, @captured, @lang)
        """;
        cmd.Parameters.AddWithValue("@text", entry.Text);
        cmd.Parameters.AddWithValue("@source", (object?)entry.SourceApplication ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@captured", entry.CapturedAt.ToString("O"));
        cmd.Parameters.AddWithValue("@lang", (object?)entry.Language ?? DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<IReadOnlyList<HistoryEntry>> GetRecentAsync(int count = 50)
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();

        var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT id, text, source_application, captured_at, language FROM history ORDER BY captured_at DESC LIMIT @count";
        cmd.Parameters.AddWithValue("@count", count);

        return await ReadEntries(cmd);
    }

    public async Task<IReadOnlyList<HistoryEntry>> SearchAsync(string query)
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();

        var cmd = connection.CreateCommand();
        cmd.CommandText = """
            SELECT h.id, h.text, h.source_application, h.captured_at, h.language
            FROM history h
            JOIN history_fts fts ON h.id = fts.rowid
            WHERE history_fts MATCH @query
            ORDER BY h.captured_at DESC
            LIMIT 100
        """;
        cmd.Parameters.AddWithValue("@query", query);

        return await ReadEntries(cmd);
    }

    public async Task DeleteAsync(long id)
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();

        var cmd = connection.CreateCommand();
        cmd.CommandText = "DELETE FROM history WHERE id = @id";
        cmd.Parameters.AddWithValue("@id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task ClearAllAsync()
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();

        var cmd = connection.CreateCommand();
        cmd.CommandText = "DELETE FROM history";
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<int> GetCountAsync()
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();

        var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM history";
        var result = await cmd.ExecuteScalarAsync();
        return Convert.ToInt32(result);
    }

    private static async Task<IReadOnlyList<HistoryEntry>> ReadEntries(SqliteCommand cmd)
    {
        var entries = new List<HistoryEntry>();
        await using var reader = await cmd.ExecuteReaderAsync();

        while (await reader.ReadAsync())
        {
            entries.Add(new HistoryEntry
            {
                Id = reader.GetInt64(0),
                Text = reader.GetString(1),
                SourceApplication = reader.IsDBNull(2) ? null : reader.GetString(2),
                CapturedAt = DateTime.Parse(reader.GetString(3)),
                Language = reader.IsDBNull(4) ? null : reader.GetString(4)
            });
        }

        return entries;
    }

    public void Dispose()
    {
        GC.SuppressFinalize(this);
    }
}
