using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ScreenTextGrab.Core.Config;

public class AppSettings
{
    // Hotkeys
    public string OverlayHotkey { get; set; } = "Win+Q";
    public string RegionHotkey { get; set; } = "Win+Shift+R";

    // OCR
    public string OcrEngine { get; set; } = "windows"; // "windows" or "tesseract"
    public string DefaultLanguage { get; set; } = "de";
    public string TessDataPath { get; set; } = "";

    // Overlay
    public bool ShowToolbar { get; set; } = true;
    public double OverlayOpacity { get; set; } = 0.05;

    // History
    public bool SaveHistory { get; set; } = true;
    public int MaxHistoryEntries { get; set; } = 1000;
    public int HistoryRetentionDays { get; set; } = 90;

    // Startup
    public bool StartWithWindows { get; set; } = false;
    public bool StartMinimized { get; set; } = true;
}

public class SettingsService
{
    private readonly string _settingsPath;
    private AppSettings _settings = new();

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.Never
    };

    public SettingsService(string? settingsPath = null)
    {
        _settingsPath = settingsPath ?? Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "ScreenTextGrab", "settings.json");

        Load();
    }

    public AppSettings Settings => _settings;

    public void Load()
    {
        try
        {
            if (File.Exists(_settingsPath))
            {
                var json = File.ReadAllText(_settingsPath);
                _settings = JsonSerializer.Deserialize<AppSettings>(json, JsonOptions)
                    ?? new AppSettings();
            }
        }
        catch
        {
            _settings = new AppSettings();
        }
    }

    public void Save()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(_settingsPath)!);
        var json = JsonSerializer.Serialize(_settings, JsonOptions);
        File.WriteAllText(_settingsPath, json);
    }
}
