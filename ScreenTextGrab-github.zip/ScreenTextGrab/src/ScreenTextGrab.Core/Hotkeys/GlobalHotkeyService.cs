using System.Runtime.InteropServices;
using System.Windows.Interop;

namespace ScreenTextGrab.Core.Hotkeys;

/// <summary>
/// Manages system-wide global hotkeys using Win32 RegisterHotKey.
/// </summary>
public interface IGlobalHotkeyService : IDisposable
{
    /// <summary>Register a global hotkey.</summary>
    /// <param name="id">Unique identifier for this hotkey.</param>
    /// <param name="modifiers">Modifier keys (Alt, Ctrl, Shift, Win).</param>
    /// <param name="key">The virtual key code.</param>
    bool Register(int id, HotkeyModifiers modifiers, uint key);

    /// <summary>Unregister a global hotkey.</summary>
    bool Unregister(int id);

    /// <summary>Fired when a registered hotkey is pressed.</summary>
    event EventHandler<HotkeyPressedEventArgs>? HotkeyPressed;
}

[Flags]
public enum HotkeyModifiers : uint
{
    None = 0x0000,
    Alt = 0x0001,
    Ctrl = 0x0002,
    Shift = 0x0004,
    Win = 0x0008,
    NoRepeat = 0x4000
}

public class HotkeyPressedEventArgs(int id) : EventArgs
{
    public int Id { get; } = id;
}

public class GlobalHotkeyService : IGlobalHotkeyService
{
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    private const int WM_HOTKEY = 0x0312;

    private IntPtr _windowHandle;
    private HwndSource? _source;
    private readonly HashSet<int> _registeredIds = [];

    public event EventHandler<HotkeyPressedEventArgs>? HotkeyPressed;

    /// <summary>
    /// Must be called from the UI thread after the window is created.
    /// </summary>
    public void Initialize(IntPtr windowHandle)
    {
        _windowHandle = windowHandle;
        _source = HwndSource.FromHwnd(windowHandle);
        _source?.AddHook(WndProc);
    }

    public bool Register(int id, HotkeyModifiers modifiers, uint key)
    {
        if (_windowHandle == IntPtr.Zero)
            throw new InvalidOperationException("Call Initialize() first.");

        var success = RegisterHotKey(_windowHandle, id, (uint)modifiers | (uint)HotkeyModifiers.NoRepeat, key);
        if (success) _registeredIds.Add(id);
        return success;
    }

    public bool Unregister(int id)
    {
        var success = UnregisterHotKey(_windowHandle, id);
        if (success) _registeredIds.Remove(id);
        return success;
    }

    private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg == WM_HOTKEY)
        {
            var id = wParam.ToInt32();
            HotkeyPressed?.Invoke(this, new HotkeyPressedEventArgs(id));
            handled = true;
        }
        return IntPtr.Zero;
    }

    public void Dispose()
    {
        foreach (var id in _registeredIds.ToList())
            Unregister(id);

        _source?.RemoveHook(WndProc);
        _source?.Dispose();
        GC.SuppressFinalize(this);
    }
}

/// <summary>
/// Well-known hotkey IDs used by the application.
/// </summary>
public static class HotkeyIds
{
    public const int OverlayMode = 1;   // Win+Shift+O
    public const int RegionMode = 2;    // Win+Shift+R
}

/// <summary>
/// Virtual key codes for common keys.
/// </summary>
public static class VirtualKeys
{
    public const uint VK_Q = 0x51;
    public const uint VK_R = 0x52;
    public const uint VK_T = 0x54;
    public const uint VK_ESCAPE = 0x1B;
}
