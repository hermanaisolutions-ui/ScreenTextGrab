using System.Drawing;
using System.Runtime.InteropServices;

namespace ScreenTextGrab.Core.Capture;

/// <summary>
/// Service for capturing screen content.
/// </summary>
public interface IScreenCaptureService
{
    /// <summary>Capture the entire active/foreground window.</summary>
    Bitmap CaptureActiveWindow();

    /// <summary>Capture a specific screen region.</summary>
    Bitmap CaptureRegion(Rectangle region);

    /// <summary>Get the bounds of the active window.</summary>
    Rectangle GetActiveWindowBounds();
}

public class ScreenCaptureService : IScreenCaptureService
{
    #region Win32 Imports

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

    [DllImport("dwmapi.dll")]
    private static extern int DwmGetWindowAttribute(IntPtr hwnd, int dwAttribute, out RECT pvAttribute, int cbAttribute);

    [DllImport("user32.dll")]
    private static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, uint nFlags);

    [StructLayout(LayoutKind.Sequential)]
    private struct RECT
    {
        public int Left, Top, Right, Bottom;
        public Rectangle ToRectangle() => new(Left, Top, Right - Left, Bottom - Top);
    }

    private const int DWMWA_EXTENDED_FRAME_BOUNDS = 9;

    #endregion

    public Bitmap CaptureActiveWindow()
    {
        var bounds = GetActiveWindowBounds();
        return CaptureRegion(bounds);
    }

    public Bitmap CaptureRegion(Rectangle region)
    {
        if (region.Width <= 0 || region.Height <= 0)
            throw new ArgumentException("Invalid capture region.");

        var bitmap = new Bitmap(region.Width, region.Height);
        using var graphics = Graphics.FromImage(bitmap);
        graphics.CopyFromScreen(region.Location, Point.Empty, region.Size);
        return bitmap;
    }

    public Rectangle GetActiveWindowBounds()
    {
        var hwnd = GetForegroundWindow();
        if (hwnd == IntPtr.Zero)
            throw new InvalidOperationException("No active window found.");

        // Try DWM first (more accurate, excludes window shadow)
        var result = DwmGetWindowAttribute(hwnd, DWMWA_EXTENDED_FRAME_BOUNDS,
            out RECT dwmRect, Marshal.SizeOf<RECT>());

        if (result == 0)
            return dwmRect.ToRectangle();

        // Fallback to GetWindowRect
        GetWindowRect(hwnd, out RECT rect);
        return rect.ToRectangle();
    }
}
