using System.Drawing;
using ScreenTextGrab.Core.Ocr;

namespace ScreenTextGrab.Core.TableDetection;

public record TableCell(int Row, int Column, string Text, RectangleF BoundingBox);

public record TableResult
{
    public required IReadOnlyList<TableCell> Cells { get; init; }
    public int RowCount { get; init; }
    public int ColumnCount { get; init; }

    /// <summary>
    /// Export as tab-separated values (pasteable into Excel).
    /// </summary>
    public string ToTsv()
    {
        if (Cells.Count == 0) return "";

        // Build grid, merging duplicate cells (same row+col) with space
        var grid = new Dictionary<(int r, int c), List<string>>();

        foreach (var cell in Cells)
        {
            var key = (cell.Row, cell.Column);
            if (!grid.ContainsKey(key))
                grid[key] = [];
            grid[key].Add(cell.Text);
        }

        var lines = new List<string>();
        for (int r = 0; r < RowCount; r++)
        {
            var cols = new string[ColumnCount];
            for (int c = 0; c < ColumnCount; c++)
            {
                var key = (r, c);
                cols[c] = grid.ContainsKey(key) ? string.Join(" ", grid[key]) : "";
            }
            lines.Add(string.Join('\t', cols));
        }
        return string.Join(Environment.NewLine, lines);
    }
}

public interface ITableDetector
{
    TableResult? DetectTable(OcrResult ocrResult);
}

/// <summary>
/// Improved table detector that:
/// 1. Groups words into rows by Y-coordinate overlap
/// 2. Detects column boundaries by finding large horizontal gaps within rows
/// 3. Builds a consistent column grid across all rows
/// 4. Merges words within the same cell
/// </summary>
public class GridTableDetector : ITableDetector
{
    public TableResult? DetectTable(OcrResult ocrResult)
    {
        // Collect all words with positions
        var allWords = new List<(string Text, RectangleF Bounds)>();

        foreach (var block in ocrResult.TextBlocks)
        {
            foreach (var line in block.Lines)
            {
                if (line.Words.Count > 0)
                {
                    foreach (var word in line.Words)
                        allWords.Add((word.Text, word.BoundingBox));
                }
                else
                {
                    allWords.Add((line.Text, line.BoundingBox));
                }
            }
        }

        if (allWords.Count < 4)
            return null;

        // Step 1: Group into rows by Y-coordinate overlap
        var rows = GroupIntoRows(allWords);

        if (rows.Count < 2)
            return null;

        // Step 2: Find column boundaries using gap analysis
        var colBoundaries = DetectColumnBoundaries(rows);

        if (colBoundaries.Count < 2)
            return null; // Need at least 2 columns

        int colCount = colBoundaries.Count;

        // Step 3: Assign each word to (row, column)
        var cells = new List<TableCell>();

        for (int rowIdx = 0; rowIdx < rows.Count; rowIdx++)
        {
            foreach (var word in rows[rowIdx])
            {
                float wordCenter = word.Bounds.X + word.Bounds.Width / 2;
                int col = AssignToColumn(wordCenter, colBoundaries);
                cells.Add(new TableCell(rowIdx, col, word.Text, word.Bounds));
            }
        }

        return new TableResult
        {
            Cells = cells,
            RowCount = rows.Count,
            ColumnCount = colCount,
        };
    }

    /// <summary>
    /// Group words into rows based on vertical overlap.
    /// Words that overlap vertically (even partially) are on the same row.
    /// </summary>
    private static List<List<(string Text, RectangleF Bounds)>> GroupIntoRows(
        List<(string Text, RectangleF Bounds)> words)
    {
        // Sort by Y position
        var sorted = words.OrderBy(w => w.Bounds.Y).ToList();
        var rows = new List<List<(string Text, RectangleF Bounds)>>();
        var currentRow = new List<(string Text, RectangleF Bounds)> { sorted[0] };
        float rowTop = sorted[0].Bounds.Y;
        float rowBottom = sorted[0].Bounds.Y + sorted[0].Bounds.Height;

        for (int i = 1; i < sorted.Count; i++)
        {
            var word = sorted[i];
            float wordMid = word.Bounds.Y + word.Bounds.Height / 2;

            // Word belongs to current row if its center is within the row's Y range
            if (wordMid >= rowTop - 2 && wordMid <= rowBottom + 2)
            {
                currentRow.Add(word);
                rowBottom = Math.Max(rowBottom, word.Bounds.Y + word.Bounds.Height);
            }
            else
            {
                // Sort current row left-to-right before storing
                currentRow.Sort((a, b) => a.Bounds.X.CompareTo(b.Bounds.X));
                rows.Add(currentRow);

                currentRow = [word];
                rowTop = word.Bounds.Y;
                rowBottom = word.Bounds.Y + word.Bounds.Height;
            }
        }

        currentRow.Sort((a, b) => a.Bounds.X.CompareTo(b.Bounds.X));
        rows.Add(currentRow);

        return rows;
    }

    /// <summary>
    /// Detect column boundaries by analyzing horizontal gaps across all rows.
    /// Finds X-positions where large gaps appear consistently across multiple rows,
    /// indicating column separators.
    /// </summary>
    private static List<(float Left, float Right)> DetectColumnBoundaries(
        List<List<(string Text, RectangleF Bounds)>> rows)
    {
        // Collect all inter-word gaps from rows with multiple words
        var allGaps = new List<(float GapStart, float GapEnd, float GapSize)>();

        foreach (var row in rows)
        {
            if (row.Count < 2) continue;

            for (int i = 0; i < row.Count - 1; i++)
            {
                float gapStart = row[i].Bounds.X + row[i].Bounds.Width;
                float gapEnd = row[i + 1].Bounds.X;
                float gapSize = gapEnd - gapStart;

                if (gapSize > 5) // Minimum gap to consider
                    allGaps.Add((gapStart, gapEnd, gapSize));
            }
        }

        if (allGaps.Count == 0)
            return [];

        // Find typical word spacing (small gaps) vs column gaps (large gaps)
        var gapSizes = allGaps.Select(g => g.GapSize).OrderBy(x => x).ToList();
        float medianGap = gapSizes[gapSizes.Count / 2];

        // Column gaps should be significantly larger than word spacing
        // Use 2.5x median gap as threshold, but minimum 15px
        float columnGapThreshold = Math.Max(medianGap * 2.5f, 15f);

        // Filter to only large gaps (column separators)
        var columnGaps = allGaps
            .Where(g => g.GapSize >= columnGapThreshold)
            .ToList();

        if (columnGaps.Count == 0)
            return [];

        // Cluster gap positions that are at similar X-coordinates
        // These represent the same column boundary seen in different rows
        var gapCenters = columnGaps
            .Select(g => (g.GapStart + g.GapEnd) / 2)
            .OrderBy(x => x)
            .ToList();

        var boundaryXPositions = ClusterValues(gapCenters, columnGapThreshold);

        // Build column ranges: 
        // Column 0: from 0 to first boundary
        // Column 1: from first boundary to second boundary
        // etc.
        var allX = rows.SelectMany(r => r.Select(w => w.Bounds.X))
            .Concat(rows.SelectMany(r => r.Select(w => w.Bounds.X + w.Bounds.Width)));

        float minX = 0;
        float maxX = allX.Any() ? allX.Max() + 50 : 10000;

        var columns = new List<(float Left, float Right)>();
        float prevBoundary = minX;

        foreach (float bx in boundaryXPositions)
        {
            columns.Add((prevBoundary, bx));
            prevBoundary = bx;
        }
        columns.Add((prevBoundary, maxX));

        return columns;
    }

    /// <summary>
    /// Cluster nearby float values and return cluster centers.
    /// </summary>
    private static List<float> ClusterValues(List<float> sortedValues, float tolerance)
    {
        if (sortedValues.Count == 0) return [];

        var clusters = new List<List<float>>();
        var current = new List<float> { sortedValues[0] };

        for (int i = 1; i < sortedValues.Count; i++)
        {
            if (sortedValues[i] - sortedValues[i - 1] <= tolerance)
            {
                current.Add(sortedValues[i]);
            }
            else
            {
                clusters.Add(current);
                current = [sortedValues[i]];
            }
        }
        clusters.Add(current);

        return clusters.Select(c => c.Average()).ToList();
    }

    /// <summary>
    /// Assign an X-coordinate to the correct column index.
    /// </summary>
    private static int AssignToColumn(float x, List<(float Left, float Right)> columns)
    {
        for (int i = 0; i < columns.Count; i++)
        {
            if (x >= columns[i].Left && x < columns[i].Right)
                return i;
        }

        // Fallback: find closest column
        int closest = 0;
        float minDist = float.MaxValue;
        for (int i = 0; i < columns.Count; i++)
        {
            float center = (columns[i].Left + columns[i].Right) / 2;
            float dist = Math.Abs(x - center);
            if (dist < minDist)
            {
                minDist = dist;
                closest = i;
            }
        }
        return closest;
    }
}
