using System.Diagnostics;
using System.Drawing;
using System.IO;
using Tesseract;
using DrawingImageFormat = System.Drawing.Imaging.ImageFormat;

namespace ScreenTextGrab.Core.Ocr;

/// <summary>
/// OCR engine using Tesseract (open source, more languages, trainable).
/// Requires tessdata files to be present.
/// </summary>
public class TesseractOcrEngine : IOcrEngine, IDisposable
{
    private readonly string _tessDataPath;
    private readonly Dictionary<string, string> _languageMap = new()
    {
        ["de"] = "deu",
        ["en"] = "eng",
        ["fr"] = "fra",
        ["es"] = "spa",
        ["it"] = "ita",
        ["pt"] = "por",
        ["nl"] = "nld",
        ["pl"] = "pol",
        ["ru"] = "rus",
        ["zh"] = "chi_sim",
        ["ja"] = "jpn",
        ["ko"] = "kor",
        ["ar"] = "ara",
        ["tr"] = "tur",
    };

    public TesseractOcrEngine(string? tessDataPath = null)
    {
        _tessDataPath = tessDataPath
            ?? Path.Combine(AppContext.BaseDirectory, "tessdata");
    }

    public string EngineName => "Tesseract";

    public bool IsAvailable => Directory.Exists(_tessDataPath)
        && Directory.GetFiles(_tessDataPath, "*.traineddata").Length > 0;

    public IReadOnlyList<string> SupportedLanguages =>
        IsAvailable
            ? Directory.GetFiles(_tessDataPath, "*.traineddata")
                .Select(f => Path.GetFileNameWithoutExtension(f))
                .ToList()
            : [];

    public async Task<OcrResult> RecognizeAsync(Bitmap image, string language = "de", CancellationToken ct = default)
    {
        if (!IsAvailable)
            throw new InvalidOperationException(
                $"Tesseract data not found at '{_tessDataPath}'. Download tessdata files first.");

        var tessLang = _languageMap.GetValueOrDefault(language, language);

        return await Task.Run(() =>
        {
            var sw = Stopwatch.StartNew();

            using var engine = new TesseractEngine(_tessDataPath, tessLang, EngineMode.Default);
            using var pix = BitmapToPix(image);
            using var page = engine.Process(pix);

            var textBlocks = ExtractBlocks(page, image.Size);

            sw.Stop();

            return new OcrResult
            {
                TextBlocks = textBlocks,
                ProcessingTime = sw.Elapsed,
                ImageSize = image.Size,
                Language = tessLang
            };
        }, ct);
    }

    private static List<OcrTextBlock> ExtractBlocks(Page page, Size imageSize)
    {
        var blocks = new List<OcrTextBlock>();

        using var iter = page.GetIterator();
        iter.Begin();

        do
        {
            if (iter.TryGetBoundingBox(PageIteratorLevel.TextLine, out var lineBounds))
            {
                var lineText = iter.GetText(PageIteratorLevel.TextLine)?.Trim() ?? "";
                if (string.IsNullOrWhiteSpace(lineText)) continue;

                var confidence = iter.GetConfidence(PageIteratorLevel.TextLine);

                var lineRect = new RectangleF(
                    lineBounds.X1, lineBounds.Y1,
                    lineBounds.Width, lineBounds.Height);

                // Extract words within this line
                var words = ExtractWords(iter);

                var ocrLine = new OcrLine(lineText, lineRect, words);
                blocks.Add(new OcrTextBlock(lineText, lineRect, [ocrLine], confidence / 100f));
            }
        } while (iter.Next(PageIteratorLevel.TextLine));

        return blocks;
    }

    private static List<OcrWord> ExtractWords(ResultIterator iter)
    {
        var words = new List<OcrWord>();

        // Note: Iterating words within a line requires careful handling
        // of the Tesseract iterator state. Simplified here.
        var lineText = iter.GetText(PageIteratorLevel.TextLine) ?? "";
        if (iter.TryGetBoundingBox(PageIteratorLevel.TextLine, out var bounds))
        {
            // Split line into approximate word positions
            var wordTexts = lineText.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (wordTexts.Length > 0)
            {
                var wordWidth = bounds.Width / (float)wordTexts.Length;
                for (int i = 0; i < wordTexts.Length; i++)
                {
                    words.Add(new OcrWord(
                        wordTexts[i],
                        new RectangleF(
                            bounds.X1 + i * wordWidth,
                            bounds.Y1,
                            wordWidth,
                            bounds.Height),
                        0.9f));
                }
            }
        }

        return words;
    }

    private static Pix BitmapToPix(Bitmap bitmap)
    {
        using var ms = new MemoryStream();
        bitmap.Save(ms, DrawingImageFormat.Png);
        ms.Seek(0, SeekOrigin.Begin);
        return Pix.LoadFromMemory(ms.ToArray());
    }

    public void Dispose()
    {
        // Cleanup if needed
        GC.SuppressFinalize(this);
    }
}
