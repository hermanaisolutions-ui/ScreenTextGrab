using System.Drawing;

namespace ScreenTextGrab.Core.Ocr;

/// <summary>
/// Represents a single recognized word with its position.
/// </summary>
public record OcrWord(string Text, RectangleF BoundingBox, float Confidence);

/// <summary>
/// Represents a line of recognized text.
/// </summary>
public record OcrLine(string Text, RectangleF BoundingBox, IReadOnlyList<OcrWord> Words);

/// <summary>
/// Represents a block of recognized text (paragraph-level).
/// </summary>
public record OcrTextBlock(string Text, RectangleF BoundingBox, IReadOnlyList<OcrLine> Lines, float Confidence);

/// <summary>
/// Complete OCR result for an image.
/// </summary>
public class OcrResult
{
    public required IReadOnlyList<OcrTextBlock> TextBlocks { get; init; }
    public required TimeSpan ProcessingTime { get; init; }
    public required Size ImageSize { get; init; }
    public string? Language { get; init; }

    /// <summary>
    /// All recognized text concatenated.
    /// </summary>
    public string FullText => string.Join(Environment.NewLine,
        TextBlocks.Select(b => b.Text));
}

/// <summary>
/// Abstraction over different OCR engines (Windows.Media.Ocr, Tesseract).
/// </summary>
public interface IOcrEngine
{
    /// <summary>
    /// Recognize text in the given image.
    /// </summary>
    Task<OcrResult> RecognizeAsync(Bitmap image, string language = "de", CancellationToken ct = default);

    /// <summary>
    /// List of supported language codes.
    /// </summary>
    IReadOnlyList<string> SupportedLanguages { get; }

    /// <summary>
    /// Display name of the engine (e.g., "Windows OCR", "Tesseract").
    /// </summary>
    string EngineName { get; }

    /// <summary>
    /// Whether this engine is available on the current system.
    /// </summary>
    bool IsAvailable { get; }
}
