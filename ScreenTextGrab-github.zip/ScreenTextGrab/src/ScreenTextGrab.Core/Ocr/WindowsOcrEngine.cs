using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using Windows.Graphics.Imaging;
using Windows.Media.Ocr;
using Windows.Storage.Streams;
using System.Runtime.InteropServices.WindowsRuntime;
using BitmapDecoder = Windows.Graphics.Imaging.BitmapDecoder;

namespace ScreenTextGrab.Core.Ocr;

/// <summary>
/// OCR engine using the built-in Windows.Media.Ocr API.
/// Available on Windows 10 1809+ with no additional setup.
/// </summary>
public class WindowsOcrEngine : IOcrEngine
{
    public string EngineName => "Windows OCR";

    public bool IsAvailable => true; // Available on Win10+

    public IReadOnlyList<string> SupportedLanguages =>
        OcrEngine.AvailableRecognizerLanguages
            .Select(l => l.LanguageTag)
            .ToList();

    public async Task<OcrResult> RecognizeAsync(Bitmap image, string language = "de", CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();

        // Find the best matching language
        var ocrLanguage = OcrEngine.AvailableRecognizerLanguages
            .FirstOrDefault(l => l.LanguageTag.StartsWith(language, StringComparison.OrdinalIgnoreCase));

        var engine = ocrLanguage != null
            ? OcrEngine.TryCreateFromLanguage(ocrLanguage)
            : OcrEngine.TryCreateFromUserProfileLanguages();

        if (engine == null)
            throw new InvalidOperationException($"No OCR engine available for language '{language}'.");

        // Preprocess: convert to high-contrast grayscale for better OCR
        using var processed = PreprocessForOcr(image);

        // Convert System.Drawing.Bitmap to SoftwareBitmap
        var softwareBitmap = await ConvertToSoftwareBitmapAsync(processed);

        // Run OCR
        var ocrResult = await engine.RecognizeAsync(softwareBitmap);

        // Convert results
        var textBlocks = ConvertResults(ocrResult, image.Size);

        sw.Stop();

        return new OcrResult
        {
            TextBlocks = textBlocks,
            ProcessingTime = sw.Elapsed,
            ImageSize = image.Size,
            Language = ocrLanguage?.LanguageTag ?? "unknown"
        };
    }

    /// <summary>
    /// Preprocess image for better OCR accuracy:
    /// - Convert to grayscale
    /// - Increase contrast
    /// - Sharpen
    /// This significantly improves recognition of colored text on colored backgrounds.
    /// </summary>
    private static Bitmap PreprocessForOcr(Bitmap source)
    {
        var result = new Bitmap(source.Width, source.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

        // Lock bits for fast pixel access
        var srcData = source.LockBits(
            new System.Drawing.Rectangle(0, 0, source.Width, source.Height),
            System.Drawing.Imaging.ImageLockMode.ReadOnly,
            System.Drawing.Imaging.PixelFormat.Format32bppArgb);
        var dstData = result.LockBits(
            new System.Drawing.Rectangle(0, 0, result.Width, result.Height),
            System.Drawing.Imaging.ImageLockMode.WriteOnly,
            System.Drawing.Imaging.PixelFormat.Format32bppArgb);

        int bytes = Math.Abs(srcData.Stride) * source.Height;
        var srcPixels = new byte[bytes];
        var dstPixels = new byte[bytes];
        Marshal.Copy(srcData.Scan0, srcPixels, 0, bytes);

        // Contrast factor (1.5 = moderate boost)
        const float contrast = 1.5f;
        const float offset = (1f - contrast) * 128f;

        for (int i = 0; i < bytes; i += 4)
        {
            // Convert to grayscale using luminance weights
            byte b = srcPixels[i];
            byte g = srcPixels[i + 1];
            byte r = srcPixels[i + 2];
            byte a = srcPixels[i + 3];

            float gray = 0.299f * r + 0.587f * g + 0.114f * b;

            // Apply contrast
            gray = gray * contrast + offset;
            byte val = (byte)Math.Clamp((int)gray, 0, 255);

            dstPixels[i] = val;     // B
            dstPixels[i + 1] = val; // G
            dstPixels[i + 2] = val; // R
            dstPixels[i + 3] = a;   // A
        }

        Marshal.Copy(dstPixels, 0, dstData.Scan0, bytes);
        source.UnlockBits(srcData);
        result.UnlockBits(dstData);

        return result;
    }

    private static List<OcrTextBlock> ConvertResults(Windows.Media.Ocr.OcrResult result, Size imageSize)
    {
        var blocks = new List<OcrTextBlock>();

        foreach (var line in result.Lines)
        {
            var words = line.Words
                .Select(w => new OcrWord(
                    w.Text,
                    new RectangleF(
                        (float)w.BoundingRect.X,
                        (float)w.BoundingRect.Y,
                        (float)w.BoundingRect.Width,
                        (float)w.BoundingRect.Height),
                    EstimateConfidence(w)))
                .Where(w => w.Confidence > 0.3f) // Filter low-confidence words
                .ToList();

            if (words.Count == 0) continue;

            var lineText = string.Join(" ", words.Select(w => w.Text));
            var lineBounds = GetBoundingRect(words.Select(w => w.BoundingBox));
            var ocrLine = new OcrLine(lineText, lineBounds, words);

            blocks.Add(new OcrTextBlock(
                lineText,
                lineBounds,
                new[] { ocrLine },
                1.0f
            ));
        }

        return blocks;
    }

    /// <summary>
    /// Estimate confidence for a word since Windows OCR doesn't provide it.
    /// Very conservative: only filters single characters with nearly square bounding
    /// boxes that are unusually large (likely icons, not text).
    /// </summary>
    private static float EstimateConfidence(Windows.Media.Ocr.OcrWord word)
    {
        var text = word.Text.Trim();
        var w = word.BoundingRect.Width;
        var h = word.BoundingRect.Height;

        // Empty text
        if (string.IsNullOrEmpty(text)) return 0f;

        // Very small bounding box (< 4px height) = noise
        if (h < 4) return 0.1f;

        // Only filter single characters that look like icons:
        // - Single char, nearly square (aspect ratio 0.8-1.2), AND very large (>40px)
        // This catches chat bubbles recognized as "9" but keeps table data
        if (text.Length == 1 && h > 40)
        {
            double aspect = w / h;
            if (aspect > 0.8 && aspect < 1.2)
                return 0.2f; // Large square single char = likely icon
        }

        return 1.0f;
    }

    private static RectangleF GetBoundingRect(IEnumerable<RectangleF> rects)
    {
        var list = rects.ToList();
        if (list.Count == 0) return RectangleF.Empty;

        float minX = list.Min(r => r.Left);
        float minY = list.Min(r => r.Top);
        float maxX = list.Max(r => r.Right);
        float maxY = list.Max(r => r.Bottom);

        return new RectangleF(minX, minY, maxX - minX, maxY - minY);
    }

    private static async Task<SoftwareBitmap> ConvertToSoftwareBitmapAsync(Bitmap bitmap)
    {
        using var ms = new MemoryStream();
        bitmap.Save(ms, ImageFormat.Png);
        var bytes = ms.ToArray();

        using var stream = new InMemoryRandomAccessStream();
        using (var writer = new Windows.Storage.Streams.DataWriter(stream.GetOutputStreamAt(0)))
        {
            writer.WriteBytes(bytes);
            await writer.StoreAsync();
            await writer.FlushAsync();
            writer.DetachStream();
        }
        stream.Seek(0);

        // Decode the stream
        var decoder = await BitmapDecoder.CreateAsync(stream);
        return await decoder.GetSoftwareBitmapAsync(
            BitmapPixelFormat.Bgra8,
            BitmapAlphaMode.Premultiplied);
    }
}
