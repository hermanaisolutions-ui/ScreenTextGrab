using System.Windows;

namespace ScreenTextGrab;

public partial class App : System.Windows.Application
{
    private System.Threading.Mutex? _mutex;

    protected override void OnStartup(StartupEventArgs e)
    {
        _mutex = new System.Threading.Mutex(true, "ScreenTextGrab_SingleInstance", out bool createdNew);
        if (!createdNew)
        {
            System.Windows.MessageBox.Show(
                "ScreenTextGrab is already running.\nCheck the system tray (▲) for the icon.",
                "ScreenTextGrab", MessageBoxButton.OK, MessageBoxImage.Information);
            Environment.Exit(0);
            return;
        }

        base.OnStartup(e);
    }
}
