using System.Drawing;
using System.Windows;
using System.Windows.Interop;
using ScreenTextGrab.Core.Capture;
using ScreenTextGrab.Core.History;
using ScreenTextGrab.Core.Hotkeys;
using ScreenTextGrab.Core.Ocr;
using ScreenTextGrab.Core.TableDetection;
using ScreenTextGrab.Views;

namespace ScreenTextGrab;

public partial class MainWindow : Window
{
    private readonly GlobalHotkeyService _hotkeyService = new();
    private readonly ScreenCaptureService _captureService = new();
    private readonly HistoryService _historyService = new();
    private readonly GridTableDetector _tableDetector = new();
    private readonly IOcrEngine _ocrEngine;
    private OverlayWindow? _activeOverlay;
    private System.Windows.Forms.NotifyIcon? _notifyIcon;

    public MainWindow()
    {
        InitializeComponent();
        _ocrEngine = new WindowsOcrEngine();
        Loaded += OnLoaded;
        Closing += OnClosing;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        // 1. Get window handle FIRST (window must be visible for this)
        var handle = new WindowInteropHelper(this).Handle;

        // 2. Register hotkey using the handle
        bool hotkeyOk = false;
        try
        {
            _hotkeyService.Initialize(handle);
            hotkeyOk = _hotkeyService.Register(
                HotkeyIds.OverlayMode,
                HotkeyModifiers.Alt,
                VirtualKeys.VK_Q);

            if (hotkeyOk)
                _hotkeyService.HotkeyPressed += OnHotkeyPressed;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Hotkey error: {ex.Message}");
        }

        // 3. Setup tray icon
        SetupTrayIcon();

        // 4. Show balloon
        if (hotkeyOk)
            ShowBalloon("ScreenTextGrab", "Running in background.\nPress Alt+Q to capture text.");
        else
            ShowBalloon("ScreenTextGrab", "Warning: Alt+Q could not be registered.");

        // 5. Now hide the window (handle stays alive)
        Hide();
    }

    private void SetupTrayIcon()
    {
        _notifyIcon = new System.Windows.Forms.NotifyIcon
        {
            Icon = CreateDefaultIcon(),
            Text = "ScreenTextGrab - Alt+Q to capture",
            Visible = true,
        };

        var menu = new System.Windows.Forms.ContextMenuStrip();

        var captureItem = new System.Windows.Forms.ToolStripMenuItem("Capture (Alt+Q)");
        captureItem.Click += async (_, _) =>
        {
            await Task.Delay(300);
            await Dispatcher.InvokeAsync(async () => await CaptureAndShowOverlay());
        };
        menu.Items.Add(captureItem);

        var historyItem = new System.Windows.Forms.ToolStripMenuItem("History");
        historyItem.Click += (_, _) => Dispatcher.Invoke(() =>
        {
            var hw = new HistoryWindow(_historyService);
            hw.Show();
        });
        menu.Items.Add(historyItem);

        menu.Items.Add(new System.Windows.Forms.ToolStripSeparator());

        var exitItem = new System.Windows.Forms.ToolStripMenuItem("Exit");
        exitItem.Click += (_, _) => Dispatcher.Invoke(() =>
        {
            _notifyIcon?.Dispose();
            System.Windows.Application.Current.Shutdown();
        });
        menu.Items.Add(exitItem);

        _notifyIcon.ContextMenuStrip = menu;

        _notifyIcon.DoubleClick += async (_, _) =>
        {
            await Task.Delay(200);
            await Dispatcher.InvokeAsync(async () => await CaptureAndShowOverlay());
        };
    }

    private static System.Drawing.Icon CreateDefaultIcon()
    {
        var bmp = new Bitmap(32, 32);
        using (var g = Graphics.FromImage(bmp))
        {
            g.Clear(System.Drawing.Color.FromArgb(30, 100, 200));
            using var font = new Font("Segoe UI", 18, System.Drawing.FontStyle.Bold);
            using var brush = new SolidBrush(System.Drawing.Color.White);
            g.DrawString("T", font, brush, 3, 2);
        }
        return System.Drawing.Icon.FromHandle(bmp.GetHicon());
    }

    private void ShowBalloon(string title, string text)
    {
        _notifyIcon?.ShowBalloonTip(3000, title, text,
            System.Windows.Forms.ToolTipIcon.Info);
    }

    private async void OnHotkeyPressed(object? sender, HotkeyPressedEventArgs e)
    {
        if (e.Id == HotkeyIds.OverlayMode)
            await CaptureAndShowOverlay();
    }

    private async Task CaptureAndShowOverlay()
    {
        try
        {
            _activeOverlay?.Close();
            await Task.Delay(150);

            var bounds = _captureService.GetActiveWindowBounds();
            var screenshot = _captureService.CaptureActiveWindow();
            var ocrResult = await _ocrEngine.RecognizeAsync(screenshot);

            if (ocrResult.TextBlocks.Count == 0)
            {
                ShowBalloon("ScreenTextGrab", "No text found.");
                return;
            }

            var tableResult = _tableDetector.DetectTable(ocrResult);
            _activeOverlay = new OverlayWindow(ocrResult, tableResult, bounds);
            _activeOverlay.TextCopied += async (_, text) =>
            {
                await _historyService.AddAsync(new HistoryEntry
                {
                    Text = text,
                    Language = ocrResult.Language
                });
            };
            _activeOverlay.Show();
        }
        catch (Exception ex)
        {
            ShowBalloon("Error", ex.Message);
        }
    }

    private void OnClosing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        _notifyIcon?.Dispose();
        _hotkeyService.Dispose();
        _historyService.Dispose();
    }
}
