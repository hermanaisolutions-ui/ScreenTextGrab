using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using ScreenTextGrab.Core.Ocr;
using ScreenTextGrab.Core.TableDetection;

namespace ScreenTextGrab.Views;

public partial class OverlayWindow : Window
{
    private readonly OcrResult _ocrResult;
    private readonly TableResult? _tableResult;
    private readonly double _dpiScale;

    public event EventHandler<string>? TextCopied;

    private record WordInfo(
        string Text,
        Rect WpfBounds,
        int LineIndex,
        System.Windows.Shapes.Rectangle HighlightRect);

    private readonly List<WordInfo> _words = [];

    // Drag state
    private bool _isDragging;
    private System.Windows.Point _dragStart;
    private System.Windows.Shapes.Rectangle? _selectionRect;
    private string _selectedText = "";

    private const double ClosePadding = 80;

    // Selection rectangle visual
    private static readonly SolidColorBrush SelectionRectFill =
        new(Color.FromArgb(25, 0, 120, 215));
    private static readonly SolidColorBrush SelectionRectStroke =
        new(Color.FromArgb(80, 0, 120, 215));
    private static readonly SolidColorBrush WordHighlightBrush =
        new(Color.FromArgb(90, 0, 120, 215));

    // DPI
    [DllImport("user32.dll")]
    private static extern IntPtr GetDC(IntPtr hWnd);
    [DllImport("gdi32.dll")]
    private static extern int GetDeviceCaps(IntPtr hdc, int nIndex);
    [DllImport("user32.dll")]
    private static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
    private const int LOGPIXELSX = 88;

    public OverlayWindow(OcrResult ocrResult, TableResult? tableResult,
        System.Drawing.Rectangle windowBounds)
    {
        InitializeComponent();
        _ocrResult = ocrResult;
        _tableResult = tableResult;
        _dpiScale = GetDpiScale();

        Left = windowBounds.X / _dpiScale;
        Top = windowBounds.Y / _dpiScale;
        Width = windowBounds.Width / _dpiScale;
        Height = windowBounds.Height / _dpiScale;

        if (tableResult != null)
            CopyTableButton.Visibility = Visibility.Visible;
        // Always show - works on selection now
        CopyTableButton.Visibility = Visibility.Visible;

        Cursor = Cursors.IBeam;
        Loaded += (_, _) => BuildOverlay();
    }

    private static double GetDpiScale()
    {
        var hdc = GetDC(IntPtr.Zero);
        var dpiX = GetDeviceCaps(hdc, LOGPIXELSX);
        ReleaseDC(IntPtr.Zero, hdc);
        return dpiX / 96.0;
    }

    // ============================================================
    //  BUILD
    // ============================================================

    private void BuildOverlay()
    {
        _words.Clear();
        TextCanvas.Children.Clear();

        int lineIdx = 0;
        foreach (var block in _ocrResult.TextBlocks)
        {
            foreach (var line in block.Lines)
            {
                if (line.Words.Count > 0)
                {
                    foreach (var word in line.Words)
                        AddWord(word.Text, word.BoundingBox, lineIdx);
                }
                else
                {
                    AddWord(line.Text, line.BoundingBox, lineIdx);
                }
                lineIdx++;
            }
        }

        // Sort reading order
        _words.Sort((a, b) =>
        {
            if (Math.Abs(a.WpfBounds.Y - b.WpfBounds.Y) < 5)
                return a.WpfBounds.X.CompareTo(b.WpfBounds.X);
            return a.WpfBounds.Y.CompareTo(b.WpfBounds.Y);
        });

        Focus();
    }

    private void AddWord(string text, System.Drawing.RectangleF ocrBounds, int lineIdx)
    {
        var x = ocrBounds.X / _dpiScale;
        var y = ocrBounds.Y / _dpiScale;
        var w = ocrBounds.Width / _dpiScale;
        var h = ocrBounds.Height / _dpiScale;

        var rect = new System.Windows.Shapes.Rectangle
        {
            Width = w + 4,
            Height = h + 2,
            Fill = Brushes.Transparent,
            IsHitTestVisible = false,
        };
        Canvas.SetLeft(rect, x - 2);
        Canvas.SetTop(rect, y - 1);
        TextCanvas.Children.Add(rect);

        _words.Add(new WordInfo(text, new Rect(x, y, w, h), lineIdx, rect));
    }

    // ============================================================
    //  MOUSE – Rectangle-based spatial selection
    // ============================================================

    private void OnCanvasMouseDown(object sender, MouseButtonEventArgs e)
    {
        var pos = e.GetPosition(TextCanvas);

        _isDragging = true;
        _dragStart = pos;

        ClearHighlights();
        RemoveSelectionRect();

        // Create visual selection rectangle
        _selectionRect = new System.Windows.Shapes.Rectangle
        {
            Fill = SelectionRectFill,
            Stroke = SelectionRectStroke,
            StrokeThickness = 1,
            IsHitTestVisible = false,
        };
        Canvas.SetLeft(_selectionRect, pos.X);
        Canvas.SetTop(_selectionRect, pos.Y);
        _selectionRect.Width = 0;
        _selectionRect.Height = 0;
        TextCanvas.Children.Add(_selectionRect);

        TextCanvas.CaptureMouse();
        e.Handled = true;
    }

    private void OnCanvasMouseMove(object sender, MouseEventArgs e)
    {
        if (!_isDragging || _selectionRect == null) return;

        var pos = e.GetPosition(TextCanvas);

        // Update selection rectangle
        double x = Math.Min(_dragStart.X, pos.X);
        double y = Math.Min(_dragStart.Y, pos.Y);
        double w = Math.Abs(pos.X - _dragStart.X);
        double h = Math.Abs(pos.Y - _dragStart.Y);

        Canvas.SetLeft(_selectionRect, x);
        Canvas.SetTop(_selectionRect, y);
        _selectionRect.Width = w;
        _selectionRect.Height = h;

        // Highlight words that intersect the selection rectangle
        var selRect = new Rect(x, y, w, h);
        UpdateSpatialSelection(selRect);
    }

    private void OnCanvasMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (!_isDragging) return;
        _isDragging = false;
        TextCanvas.ReleaseMouseCapture();

        RemoveSelectionRect();

        _selectedText = BuildSelectedText();

        if (!string.IsNullOrEmpty(_selectedText))
        {
            try { Clipboard.SetText(_selectedText); } catch { }

            SelectionInfo.Text = _selectedText.Length > 120
                ? _selectedText[..120].Replace("\r\n", " ").Replace("\n", " ") + "…"
                : _selectedText.Replace("\r\n", " ").Replace("\n", " ");
            StatusBar.Visibility = Visibility.Visible;
            ShowFeedback("Copied!");
        }
        else
        {
            // Nothing selected → if it was just a click (no drag), close
            var pos = e.GetPosition(TextCanvas);
            if ((pos - _dragStart).Length < 5)
                Close();
        }
    }

    /// <summary>
    /// Select words based on spatial overlap with the selection rectangle.
    /// A word is selected if its center point falls within the expanded selection rect,
    /// OR if there is significant overlap between the word and selection rect.
    /// </summary>
    private void UpdateSpatialSelection(Rect selRect)
    {
        // Generous expansion for tolerance
        var expanded = new Rect(
            selRect.X - 10, selRect.Y - 10,
            selRect.Width + 20, selRect.Height + 20);

        foreach (var w in _words)
        {
            // Check 1: word center inside selection rect
            double cx = w.WpfBounds.X + w.WpfBounds.Width / 2;
            double cy = w.WpfBounds.Y + w.WpfBounds.Height / 2;
            bool centerInside = expanded.Contains(cx, cy);

            // Check 2: any overlap at all with expanded rect
            bool overlaps = w.WpfBounds.IntersectsWith(expanded);

            // Select if center is inside OR there's overlap
            bool selected = centerInside || overlaps;

            w.HighlightRect.Fill = selected ? WordHighlightBrush : Brushes.Transparent;
        }
    }

    private void ClearHighlights()
    {
        foreach (var w in _words)
            w.HighlightRect.Fill = Brushes.Transparent;
        _selectedText = "";
        StatusBar.Visibility = Visibility.Collapsed;
    }

    private void RemoveSelectionRect()
    {
        if (_selectionRect != null)
        {
            TextCanvas.Children.Remove(_selectionRect);
            _selectionRect = null;
        }
    }

    private string BuildSelectedText()
    {
        var selected = _words
            .Where(w => w.HighlightRect.Fill != Brushes.Transparent)
            .ToList();

        if (selected.Count == 0) return "";

        // Group into visual rows by Y-overlap
        var rows = GroupIntoRows(selected);
        var sb = new System.Text.StringBuilder();

        foreach (var row in rows)
        {
            if (sb.Length > 0)
                sb.AppendLine();

            // Sort left-to-right
            row.Sort((a, b) => a.WpfBounds.X.CompareTo(b.WpfBounds.X));

            for (int i = 0; i < row.Count; i++)
            {
                if (i > 0)
                    sb.Append(' ');
                sb.Append(row[i].Text);
            }
        }

        return sb.ToString().Trim();
    }

    /// <summary>
    /// Group words into rows based on vertical overlap.
    /// </summary>
    private static List<List<WordInfo>> GroupIntoRows(List<WordInfo> words)
    {
        if (words.Count == 0) return [];

        var sorted = words.OrderBy(w => w.WpfBounds.Y).ToList();
        var rows = new List<List<WordInfo>>();
        var currentRow = new List<WordInfo> { sorted[0] };
        double rowTop = sorted[0].WpfBounds.Y;
        double rowBottom = sorted[0].WpfBounds.Bottom;

        for (int i = 1; i < sorted.Count; i++)
        {
            double wordMidY = sorted[i].WpfBounds.Y + sorted[i].WpfBounds.Height / 2;

            if (wordMidY >= rowTop - 3 && wordMidY <= rowBottom + 3)
            {
                currentRow.Add(sorted[i]);
                rowBottom = Math.Max(rowBottom, sorted[i].WpfBounds.Bottom);
            }
            else
            {
                rows.Add(currentRow);
                currentRow = [sorted[i]];
                rowTop = sorted[i].WpfBounds.Y;
                rowBottom = sorted[i].WpfBounds.Bottom;
            }
        }
        rows.Add(currentRow);

        return rows;
    }

    // ============================================================
    //  HIT TESTING
    // ============================================================

    private (int idx, double dist) FindNearest(System.Windows.Point pos)
    {
        int best = -1;
        double bestDist = double.MaxValue;
        for (int i = 0; i < _words.Count; i++)
        {
            var d = DistToRect(pos, _words[i].WpfBounds);
            if (d < bestDist) { bestDist = d; best = i; }
        }
        return (best, bestDist);
    }

    private static double DistToRect(System.Windows.Point p, Rect r)
    {
        double dx = Math.Max(r.Left - p.X, Math.Max(0, p.X - r.Right));
        double dy = Math.Max(r.Top - p.Y, Math.Max(0, p.Y - r.Bottom));
        return Math.Sqrt(dx * dx + dy * dy);
    }

    // ============================================================
    //  KEYBOARD
    // ============================================================

    private void OnKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            Close();
        }
        else if (e.Key == Key.C && Keyboard.Modifiers == ModifierKeys.Control)
        {
            if (!string.IsNullOrEmpty(_selectedText))
            {
                try { Clipboard.SetText(_selectedText); } catch { }
                ShowFeedback("Copied!");
            }
        }
        else if (e.Key == Key.A && Keyboard.Modifiers == ModifierKeys.Control)
        {
            foreach (var w in _words) w.HighlightRect.Fill = WordHighlightBrush;
            _selectedText = BuildSelectedText();
            try { Clipboard.SetText(_selectedText); } catch { }
            SelectionInfo.Text = $"All ({_words.Count} words)";
            StatusBar.Visibility = Visibility.Visible;
            ShowFeedback("All copied!");
        }
        e.Handled = true;
    }

    // ============================================================
    //  TOOLBAR
    // ============================================================

    private void OnCopyAll(object sender, RoutedEventArgs e)
    {
        try { Clipboard.SetText(_ocrResult.FullText); ShowFeedback("All copied!"); } catch { }
    }

    private void OnCopyAsTable(object sender, RoutedEventArgs e)
    {
        try
        {
            // Use selected words if any, otherwise all words
            var wordsToUse = _words
                .Where(w => w.HighlightRect.Fill != Brushes.Transparent)
                .ToList();

            if (wordsToUse.Count == 0)
                wordsToUse = _words;

            var tsv = BuildTableTsv(wordsToUse);
            if (!string.IsNullOrEmpty(tsv))
            {
                Clipboard.SetText(tsv);
                ShowFeedback("Table copied!");
            }
        }
        catch { }
    }

    /// <summary>
    /// Build tab-separated text from words, detecting columns by horizontal gaps.
    /// </summary>
    private static string BuildTableTsv(List<WordInfo> words)
    {
        if (words.Count == 0) return "";

        var rows = GroupIntoRows(words);

        // Collect all inter-word gaps across all rows to find column boundaries
        var allGaps = new List<(double Center, double Size)>();
        foreach (var row in rows)
        {
            row.Sort((a, b) => a.WpfBounds.X.CompareTo(b.WpfBounds.X));
            for (int i = 0; i < row.Count - 1; i++)
            {
                double gapStart = row[i].WpfBounds.Right;
                double gapEnd = row[i + 1].WpfBounds.Left;
                double gapSize = gapEnd - gapStart;
                if (gapSize > 5)
                    allGaps.Add(((gapStart + gapEnd) / 2, gapSize));
            }
        }

        if (allGaps.Count == 0)
        {
            // No gaps found, just join as lines
            var sb2 = new System.Text.StringBuilder();
            foreach (var row in rows)
            {
                if (sb2.Length > 0) sb2.AppendLine();
                row.Sort((a, b) => a.WpfBounds.X.CompareTo(b.WpfBounds.X));
                sb2.Append(string.Join(" ", row.Select(w => w.Text)));
            }
            return sb2.ToString();
        }

        // Find threshold: median gap * 2 or at least 20px
        var gapSizes = allGaps.Select(g => g.Size).OrderBy(x => x).ToList();
        double median = gapSizes[gapSizes.Count / 2];
        double threshold = Math.Max(median * 2, 20);

        // Build output: large gap = tab, small gap = space
        var sb = new System.Text.StringBuilder();
        foreach (var row in rows)
        {
            if (sb.Length > 0) sb.AppendLine();
            row.Sort((a, b) => a.WpfBounds.X.CompareTo(b.WpfBounds.X));

            for (int i = 0; i < row.Count; i++)
            {
                if (i > 0)
                {
                    double gap = row[i].WpfBounds.Left - row[i - 1].WpfBounds.Right;
                    sb.Append(gap > threshold ? '\t' : ' ');
                }
                sb.Append(row[i].Text);
            }
        }

        return sb.ToString().Trim();
    }

    private void OnClose(object sender, RoutedEventArgs e) => Close();

    private void ShowFeedback(string msg)
    {
        var fb = new Border
        {
            Background = new SolidColorBrush(Color.FromArgb(220, 40, 167, 69)),
            CornerRadius = new CornerRadius(4),
            Padding = new Thickness(12, 6, 12, 6),
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(0, 0, 0, 50),
            Child = new TextBlock { Text = msg, Foreground = Brushes.White, FontSize = 13 }
        };
        var grid = (Grid)Content;
        grid.Children.Add(fb);
        var t = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };
        t.Tick += (_, _) => { grid.Children.Remove(fb); t.Stop(); };
        t.Start();
    }
}
