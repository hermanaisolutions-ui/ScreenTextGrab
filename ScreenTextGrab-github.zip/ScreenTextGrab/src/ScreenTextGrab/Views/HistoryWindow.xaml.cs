using System.Windows;
using System.Windows.Controls;
using ScreenTextGrab.Core.History;

namespace ScreenTextGrab.Views;

public partial class HistoryWindow : Window
{
    private readonly IHistoryService _historyService;

    public HistoryWindow(IHistoryService historyService)
    {
        InitializeComponent();
        _historyService = historyService;
        Loaded += async (_, _) => await LoadHistory();
    }

    private async Task LoadHistory()
    {
        var entries = await _historyService.GetRecentAsync(100);
        HistoryList.ItemsSource = entries;
        var count = await _historyService.GetCountAsync();
        StatusText.Text = $"{count} entries total";
    }

    private async void OnSearchChanged(object sender, TextChangedEventArgs e)
    {
        var query = SearchBox.Text;
        SearchPlaceholder.Visibility = string.IsNullOrEmpty(query)
            ? Visibility.Visible : Visibility.Collapsed;

        if (string.IsNullOrWhiteSpace(query))
        {
            await LoadHistory();
            return;
        }

        if (query.Length < 2) return;

        try
        {
            var results = await _historyService.SearchAsync(query);
            HistoryList.ItemsSource = results;
            StatusText.Text = $"{results.Count} results";
        }
        catch
        {
            // FTS query might fail on special characters
        }
    }

    private void OnCopySelected(object sender, RoutedEventArgs e)
    {
        if (HistoryList.SelectedItem is HistoryEntry entry)
        {
            Clipboard.SetText(entry.Text);
        }
    }

    private async void OnClearAll(object sender, RoutedEventArgs e)
    {
        var result = MessageBox.Show(
            "Delete all history entries?",
            "ScreenTextGrab", MessageBoxButton.YesNo, MessageBoxImage.Warning);

        if (result == MessageBoxResult.Yes)
        {
            await _historyService.ClearAllAsync();
            await LoadHistory();
        }
    }
}
