// Resolve WinForms vs WPF naming conflicts
global using Brushes = System.Windows.Media.Brushes;
global using Color = System.Windows.Media.Color;
global using Clipboard = System.Windows.Clipboard;
global using MessageBox = System.Windows.MessageBox;
global using Cursors = System.Windows.Input.Cursors;
global using HorizontalAlignment = System.Windows.HorizontalAlignment;
global using VerticalAlignment = System.Windows.VerticalAlignment;
global using MouseEventArgs = System.Windows.Input.MouseEventArgs;
global using KeyEventArgs = System.Windows.Input.KeyEventArgs;
global using FontFamily = System.Windows.Media.FontFamily;
