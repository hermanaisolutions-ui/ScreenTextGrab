# Security Audit — ScreenTextGrab

**Date:** 2026-02-18
**Scope:** All source files in `src/`

## Summary

✅ **No critical security issues found.** The application is safe for open-source release.

## Detailed Findings

### ✅ No Network Activity
- The application makes **zero network requests**
- All OCR processing is done locally via `Windows.Media.Ocr`
- No telemetry, analytics, or update checks
- No external API calls

### ✅ No Secrets or Credentials
- No API keys, passwords, or tokens in the codebase
- No hardcoded credentials
- Settings stored as plain JSON in `%LOCALAPPDATA%`

### ✅ SQL Injection Protection
- `HistoryService.cs` uses **parameterized queries** throughout (`@text`, `@source`, etc.)
- FTS5 search query is also parameterized
- No string concatenation for SQL

### ✅ Safe File Operations
- Database path uses `Environment.SpecialFolder.LocalApplicationData` (user-scoped)
- Settings path also user-scoped
- No writes outside of `%LOCALAPPDATA%\ScreenTextGrab\`
- `Directory.CreateDirectory` is used safely

### ✅ Win32 API Usage
- P/Invoke calls are limited to:
  - `user32.dll`: `GetForegroundWindow`, `GetWindowRect`, `RegisterHotKey`, `UnregisterHotKey`, `GetDC`, `ReleaseDC`
  - `dwmapi.dll`: `DwmGetWindowAttribute`
  - `gdi32.dll`: `GetDeviceCaps`, `CopyFromScreen`
- All standard Windows APIs, no elevated privileges needed
- No process injection or hooking

### ✅ Memory Safety
- `Bitmap` objects use `using` statements for disposal
- `LockBits`/`UnlockBits` in `PreprocessForOcr` are properly paired
- SQLite connections use `await using` for cleanup
- `Marshal.Copy` operates on known-size buffers

### ✅ Input Validation
- `CaptureRegion` validates region bounds before capturing
- OCR engine validates language availability
- Mutex prevents multiple instances

### ℹ️ Low-Risk Notes (informational only)

1. **Clipboard access**: App writes to clipboard — expected behavior for a copy tool
2. **Screen capture**: App captures the foreground window — this is the core feature
3. **History database not encrypted**: Captured text is stored in plaintext SQLite. This is acceptable since:
   - It's user-local (`%LOCALAPPDATA%`)
   - Same security level as browser history or clipboard managers
   - Users can clear history via UI
4. **No code signing**: The EXE is unsigned. Windows SmartScreen may warn on first launch. Consider signing for distribution.
5. **Icon memory**: `CreateDefaultIcon` uses `GetHicon()` which creates an unmanaged icon handle — minor leak on exit only, acceptable for a tray icon created once.

## Permissions Required

- **None** — No admin rights needed
- No special Windows permissions
- No UAC elevation

## Dependencies

| Package | Version | License | Risk |
|---------|---------|---------|------|
| Microsoft.Data.Sqlite | NuGet | MIT | ✅ Safe |
| CommunityToolkit.Mvvm | 8.2.2 | MIT | ✅ Safe |
| .NET 8 Runtime | Self-contained | MIT | ✅ Safe |

## Recommendation

**✅ Safe for open-source release.** No changes required.

Optional improvements for future versions:
- Add code signing certificate for EXE
- Option to encrypt history database
- Add `SECURITY.md` with vulnerability reporting guidelines
