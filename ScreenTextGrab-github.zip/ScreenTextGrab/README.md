# ScreenTextGrab

**Copy text from anywhere on your screen — even from images, PDFs, and applications that don't allow text selection.**

ScreenTextGrab uses Windows OCR to recognize text in any window and lets you select and copy it with a simple rectangle drag.

![Windows 10+](https://img.shields.io/badge/Windows-10%2F11-blue) ![.NET 8](https://img.shields.io/badge/.NET-8.0-purple) ![License MIT](https://img.shields.io/badge/License-MIT-green)

## Features

- **Alt+Q** hotkey to capture text from the active window
- **Rectangle selection** — drag to select exactly the text you need
- **Auto-copy** — text is copied to clipboard on release
- **Copy as Table** — preserves column structure with tab separators (paste into Excel)
- **System tray** — runs silently in the background
- **Image preprocessing** — grayscale + contrast boost for better OCR on colored backgrounds
- **History** — searchable SQLite database of all captured text
- **Single EXE** — no installation, no dependencies, fully self-contained
- **Offline** — all processing happens locally, no data leaves your machine

## Quick Start

1. Download `ScreenTextGrab.exe` from [Releases](../../releases)
2. Double-click to run — a blue **"T"** icon appears in the system tray
3. Press **Alt+Q** over any window
4. Drag a rectangle over the text you want
5. Text is automatically copied — paste with **Ctrl+V**

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Alt+Q | Capture active window |
| Drag | Select text area |
| Ctrl+A | Select all recognized text |
| Ctrl+C | Copy selected text |
| ESC | Close overlay |
| Click (no drag) | Close overlay |

## Building from Source

### Prerequisites
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) (Windows x64)

### Build
```powershell
git clone https://github.com/hermanaisolutions-ui/ScreenTextGrab.git
cd ScreenTextGrab
dotnet publish src\ScreenTextGrab\ScreenTextGrab.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:EnableCompressionInSingleFile=true -o publish
```

The self-contained EXE will be at `publish/ScreenTextGrab.exe`.

## Autostart

To run ScreenTextGrab at Windows startup:
1. Press `Win+R`, type `shell:startup`, press Enter
2. Create a shortcut to `ScreenTextGrab.exe` in the opened folder

## Architecture

- **ScreenTextGrab** — WPF UI layer (overlay, tray icon, selection)
- **ScreenTextGrab.Core** — Business logic (OCR, capture, history, table detection)
- **Windows.Media.Ocr** — Built-in Windows OCR engine (no external dependencies)
- **SQLite** — Local history storage

## Privacy

ScreenTextGrab processes everything locally. No data is sent to any server. The history database is stored in `%LOCALAPPDATA%\ScreenTextGrab\history.db`.

## License

[MIT](LICENSE)
